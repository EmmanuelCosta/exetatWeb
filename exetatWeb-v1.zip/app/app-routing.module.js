"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
const core_1 = require('@angular/core');
const router_1 = require('@angular/router');
const accueil_component_1 = require('./accueil/accueil.component');
const sections_component_1 = require('./section/sections.component');
const section_form_component_1 = require('./section/section-form.component');
const subjects_component_1 = require('./subject/subjects.component');
const subject_form_component_1 = require('./subject/subject-form.component');
const items_component_1 = require('./item/items.component');
const item_form_component_1 = require('./item/item-form.component');
//import { QuestionsComponent } from './question/questions.component';
const question_form_component_1 = require('./question/question-form.component');
const routes = [
    { path: '', redirectTo: '/accueil', pathMatch: 'full' },
    { path: 'accueil', component: accueil_component_1.AccueilComponent },
    { path: 'sections', component: sections_component_1.SectionsComponent },
    { path: 'addSection', component: section_form_component_1.SectionFormComponent },
    { path: 'subjects', component: subjects_component_1.SubjectsComponent },
    { path: 'addSubject', component: subject_form_component_1.SubjectFormComponent },
    { path: 'items', component: items_component_1.ItemsComponent },
    { path: 'addItem', component: item_form_component_1.ItemFormComponent },
    //  { path: 'questions',  component: QuestionsComponent },
    { path: 'addQuestion/:item_id', component: question_form_component_1.QuestionFormComponent },
];
let AppRoutingModule = class AppRoutingModule {
};
AppRoutingModule = __decorate([
    core_1.NgModule({
        imports: [router_1.RouterModule.forRoot(routes)],
        exports: [router_1.RouterModule]
    }), 
    __metadata('design:paramtypes', [])
], AppRoutingModule);
exports.AppRoutingModule = AppRoutingModule;
//# sourceMappingURL=app-routing.module.js.map