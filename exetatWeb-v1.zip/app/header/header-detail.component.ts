import { Component } from '@angular/core';


@Component({
  moduleId: module.id,
  selector: 'header-detail',
  templateUrl:'header-detail.component.html'
})
export class HeaderDetailComponent {

}