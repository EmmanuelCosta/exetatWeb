export class Section{
    _id: string;
    name: string;
   
    subject:[
    {
        id:string;
        name:string
      }
    ]
}