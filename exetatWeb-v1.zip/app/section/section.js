"use strict";
class Section {
}
exports.Section = Section;
//# sourceMappingURL=section.js.map