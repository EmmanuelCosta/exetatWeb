"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
require('rxjs/add/operator/switchMap');
const core_1 = require('@angular/core');
const router_1 = require('@angular/router');
const common_1 = require('@angular/common');
const section_1 = require('./section');
const section_service_1 = require('./section.service');
let SectionFormComponent = class SectionFormComponent {
    constructor(sectionService, route, router, location) {
        this.sectionService = sectionService;
        this.route = route;
        this.router = router;
        this.location = location;
    }
    ngOnInit() {
        this.section = new section_1.Section();
    }
    newSection() {
        this.sectionService.newSection(this.section);
        this.location.replaceState('/'); // clears browser history so they can't navigate with back button
        this.router.navigate(['/sections']);
    }
    onSubmit() {
        this.section.name += "register";
    }
};
SectionFormComponent = __decorate([
    core_1.Component({
        moduleId: module.id,
        selector: 'section-form',
        templateUrl: 'section-form.component.html',
        styleUrls: ['../../assets/css/forms.css']
    }), 
    __metadata('design:paramtypes', [section_service_1.SectionService, router_1.ActivatedRoute, router_1.Router, common_1.Location])
], SectionFormComponent);
exports.SectionFormComponent = SectionFormComponent;
//# sourceMappingURL=section-form.component.js.map