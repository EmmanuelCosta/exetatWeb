"use strict";
class Subject {
}
exports.Subject = Subject;
//# sourceMappingURL=subject.js.map