"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
require('rxjs/add/operator/switchMap');
const core_1 = require('@angular/core');
const router_1 = require('@angular/router');
const common_1 = require('@angular/common');
const subject_1 = require('./subject');
const subject_service_1 = require('./subject.service');
const section_service_1 = require('../section/section.service');
let SubjectFormComponent = class SubjectFormComponent {
    constructor(subjectService, sectionService, route, router, location) {
        this.subjectService = subjectService;
        this.sectionService = sectionService;
        this.route = route;
        this.router = router;
        this.location = location;
    }
    getSections() {
        this.sectionService
            .getSections()
            .then(sections => this.sections = sections);
    }
    choosedSections(section) {
        if (document.getElementById(section.name).checked === true) {
            this.checkedSections.push(section);
        }
        else if (document.getElementById(section.name).checked === false) {
            let indexx = this.checkedSections.indexOf(section);
            this.checkedSections.splice(indexx, 1);
        }
    }
    ngOnInit() {
        this.subject = new subject_1.Subject();
        this.subject.section = [];
        this.getSections();
        this.checkedSections = [];
    }
    newSubject() {
        for (var section of this.checkedSections) {
            this.subject.section.push(section._id);
        }
        this.subjectService.newSubject(this.subject);
        this.location.replaceState('/'); // clears browser history so they can't navigate with back button
        this.router.navigate(['/subjects']);
    }
    onSubmit() {
        this.subject.name += "register";
    }
};
SubjectFormComponent = __decorate([
    core_1.Component({
        moduleId: module.id,
        selector: 'subject-form',
        templateUrl: 'subject-form.component.html',
        styleUrls: ['../../assets/css/forms.css']
    }), 
    __metadata('design:paramtypes', [subject_service_1.SubjectService, section_service_1.SectionService, router_1.ActivatedRoute, router_1.Router, common_1.Location])
], SubjectFormComponent);
exports.SubjectFormComponent = SubjectFormComponent;
//# sourceMappingURL=subject-form.component.js.map