import { Component } from '@angular/core';


@Component({
  moduleId: module.id,
  selector: 'footer-detail',
  templateUrl:'footer-detail.component.html'
})
export class FooterDetailComponent {

}