import { Component } from '@angular/core';


@Component({
  moduleId: module.id,
  selector: 'acceuil',
  templateUrl:'accueil.component.html'
})
export class AccueilComponent {

}