export class Item{
    _id:string;
   serie:string;
   year:string;
   subject:string[];
   question:string[]
   
}