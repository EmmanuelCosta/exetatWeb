"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
require('rxjs/add/operator/switchMap');
const core_1 = require('@angular/core');
const router_1 = require('@angular/router');
const common_1 = require('@angular/common');
const subject_service_1 = require('../subject/subject.service');
const item_1 = require('./item');
const item_service_1 = require('./item.service');
let ItemFormComponent = class ItemFormComponent {
    constructor(itemService, subjectService, route, router, location) {
        this.itemService = itemService;
        this.subjectService = subjectService;
        this.route = route;
        this.router = router;
        this.location = location;
    }
    getSubjects() {
        this.subjectService
            .getSubjects()
            .then(subjects => this.subjects = subjects);
    }
    choosedSubjects(subject) {
        if (document.getElementById(subject._id).checked === true) {
            this.checkedSubjects.push(subject);
        }
        else if (document.getElementById(subject._id).checked === false) {
            let indexx = this.checkedSubjects.indexOf(subject);
            this.checkedSubjects.splice(indexx, 1);
        }
    }
    ngOnInit() {
        this.item = new item_1.Item();
        this.item.subject = [];
        this.getSubjects();
        this.checkedSubjects = [];
        this.series = ["A", "B", "C", "D"];
        this.allowYears = [];
        for (var i = 1900; i < 2018; i++) {
            this.allowYears.push(i);
        }
    }
    newItem() {
        for (var subject of this.checkedSubjects) {
            this.item.subject.push(subject._id);
        }
        console.log("===> " + this.item.year);
        this.itemService.newItem(this.item);
        this.location.replaceState('/'); // clears browser history so they can't navigate with back button
        this.router.navigate(['/items']);
    }
};
ItemFormComponent = __decorate([
    core_1.Component({
        moduleId: module.id,
        selector: 'item-form',
        templateUrl: 'item-form.component.html',
        styleUrls: ['../../assets/css/forms.css']
    }), 
    __metadata('design:paramtypes', [item_service_1.ItemService, subject_service_1.SubjectService, router_1.ActivatedRoute, router_1.Router, common_1.Location])
], ItemFormComponent);
exports.ItemFormComponent = ItemFormComponent;
//# sourceMappingURL=item-form.component.js.map