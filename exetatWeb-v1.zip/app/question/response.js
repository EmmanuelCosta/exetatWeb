"use strict";
class Response {
}
exports.Response = Response;
//# sourceMappingURL=response.js.map