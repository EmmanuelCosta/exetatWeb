export class Response{
    libelle:string;
    status:boolean;
}