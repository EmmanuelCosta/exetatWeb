"use strict";
class Question {
    constructor() {
        this.answer = new Array();
    }
}
exports.Question = Question;
//# sourceMappingURL=Question.js.map