"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
require('rxjs/add/operator/switchMap');
const core_1 = require('@angular/core');
const router_1 = require('@angular/router');
const common_1 = require('@angular/common');
const question_1 = require('../question/question');
const question_service_1 = require('../question/question.service');
const item_service_1 = require('../item/item.service');
const response_1 = require('../question/response');
let QuestionFormComponent = class QuestionFormComponent {
    constructor(itemService, questionService, route, router, location, element) {
        this.itemService = itemService;
        this.questionService = questionService;
        this.route = route;
        this.router = router;
        this.location = location;
        this.element = element;
    }
    getIndex(itemId) {
        this.questionService
            .getNextIndex(itemId)
            .then(index => this.index = index);
    }
    ngOnInit() {
        this.question = new question_1.Question();
        this.route.params.subscribe(params => {
            var id = params['item_id'];
            this.question.item = id;
            this.getIndex(id);
        });
    }
    createRange(number) {
        var items = [];
        for (var i = 0; i < number; i++) {
            items.push(i);
        }
        return items;
    }
    setNumberOfAnswer(answerNumber) {
        this.answerNumber = answerNumber;
        console.log(this.answerNumber);
    }
    newQuestion() {
        this.question.index = this.index;
        this.setAnswer();
        for (var i = 0; i < this.answerNumber; i++) {
            console.log(this.question.answer[i].libelle);
        }
        this.questionService.newQuestion(this.question);
        this.location.replaceState('/'); // clears browser history so they can't navigate with back button
        this.router.navigate(['/items']);
    }
    setAnswer() {
        var el = this.element.nativeElement;
        for (var i = 0; i < this.answerNumber; i++) {
            var answerValue = el.querySelector('#answer' + i).value;
            var statusValue = el.querySelector('#status' + i).value;
            var response = new response_1.Response();
            response.status = statusValue;
            response.libelle = answerValue;
            this.question.answer.push(response);
        }
    }
};
QuestionFormComponent = __decorate([
    core_1.Component({
        moduleId: module.id,
        selector: 'question-form',
        templateUrl: 'question-form.component.html',
        styleUrls: ['../../assets/css/forms.css']
    }), 
    __metadata('design:paramtypes', [item_service_1.ItemService, question_service_1.QuestionService, router_1.ActivatedRoute, router_1.Router, common_1.Location, core_1.ElementRef])
], QuestionFormComponent);
exports.QuestionFormComponent = QuestionFormComponent;
//# sourceMappingURL=question-form.component.js.map